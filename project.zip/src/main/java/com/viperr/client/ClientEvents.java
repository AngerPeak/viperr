package com.viperr.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.viperr.ModConfigs;
import com.viperr.Tracks;
import com.viperr.Viperr;
import com.viperr.world.HallLayout;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Viperr.MODID, value = Dist.CLIENT)
public class ClientEvents {
    private static final int[] TINTS = {0xFF1177, 0x3366FF, 0x22FF66, 0xAA22FF, 0xFFE62E};

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            ClientHallState.tick();
        }
    }

    /** Colour wash + strobe flashes over the whole screen while you are in the hall. */
    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        if (!ClientHallState.inHall() || !ModConfigs.STROBE.get()) return;
        GuiGraphics g = event.getGuiGraphics();
        int w = event.getWindow().getGuiScaledWidth();
        int h = event.getWindow().getGuiScaledHeight();
        long t = System.currentTimeMillis();

        int tint = TINTS[(int) ((t / 450L) % TINTS.length)];
        g.fill(0, 0, w, h, (0x1C << 24) | tint);

        long cycle = t % 9000L;
        if (cycle < 1500L && ((t / 90L) % 2L) == 0L) {
            g.fill(0, 0, w, h, 0x50FFFFFF);
        }
    }

    /** The big screen behind the stage: current track in rainbow letters. */
    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!ClientHallState.inHall()) return;
        Minecraft mc = Minecraft.getInstance();
        Vec3 cam = event.getCamera().getPosition();
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        Font font = mc.font;
        long t = System.currentTimeMillis();

        ps.pushPose();
        ps.translate(HallLayout.SCREEN_CX - cam.x, HallLayout.SCREEN_CY - cam.y, HallLayout.SCREEN_Z - 0.03D - cam.z);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F)); // face the audience (towards -z)

        int rainbow = 0xFF000000 | Mth.hsvToRgb((t % 5000L) / 5000.0F, 0.75F, 1.0F);
        int rainbow2 = 0xFF000000 | Mth.hsvToRgb(((t + 2500L) % 5000L) / 5000.0F, 0.75F, 1.0F);

        boolean playing = ClientHallState.track >= 0 && ClientHallState.track < Tracks.COUNT;
        drawLine(font, ps, buf, Component.literal(playing ? "NOW PLAYING" : "VIPERR HALL").withStyle(ChatFormatting.BOLD),
                4.6F, 0.22F, 30.0F, 0xFFFFFFFF);
        drawLine(font, ps, buf, Component.literal(playing ? Tracks.NAMES[ClientHallState.track].toUpperCase() : "KAI ANGEL x 9MICE").withStyle(ChatFormatting.BOLD),
                0.0F, 0.6F, 35.0F, rainbow);
        drawLine(font, ps, buf, Component.literal("KAI ANGEL  x  9MICE").withStyle(ChatFormatting.BOLD),
                -4.6F, 0.26F, 30.0F, rainbow2);

        buf.endBatch();
        ps.popPose();
    }

    private static void drawLine(Font font, PoseStack ps, MultiBufferSource buf, Component text, float y, float maxScale, float maxWidthBlocks, int color) {
        float width = font.width(text);
        float scale = Math.min(maxScale, maxWidthBlocks / Math.max(1.0F, width));
        ps.pushPose();
        ps.translate(0.0D, y, 0.0D);
        ps.scale(scale, -scale, scale);
        font.drawInBatch(text, -width / 2.0F, -font.lineHeight / 2.0F, color, false, ps.last().pose(), buf,
                Font.DisplayMode.NORMAL, 0, 15728880);
        ps.popPose();
    }
}
