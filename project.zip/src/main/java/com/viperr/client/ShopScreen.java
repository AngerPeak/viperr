package com.viperr.client;

import com.viperr.network.BuyPacket;
import com.viperr.network.ModNetwork;
import com.viperr.shop.ShopCatalog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;

public class ShopScreen extends Screen {
    private final int shop;

    public ShopScreen(int shop) {
        super(Component.translatable(shop == 0 ? "gui.viperr.bar" : "gui.viperr.kiosk"));
        this.shop = shop;
    }

    @Override
    protected void init() {
        List<ShopCatalog.Entry> list = ShopCatalog.SHOPS.get(shop);
        int y = this.height / 2 - (list.size() * 24) / 2 + 6;
        for (int i = 0; i < list.size(); i++) {
            final int idx = i;
            ShopCatalog.Entry e = list.get(i);
            Component name = new ItemStack(e.item().get()).getHoverName();
            this.addRenderableWidget(Button.builder(Component.translatable("gui.viperr.buy", name, e.price()),
                    b -> ModNetwork.CHANNEL.sendToServer(new BuyPacket(shop, idx)))
                    .bounds(this.width / 2 - 90, y + i * 24, 200, 20).build());
        }
        this.addRenderableWidget(Button.builder(Component.translatable("gui.viperr.close"), b -> this.onClose())
                .bounds(this.width / 2 - 50, y + list.size() * 24 + 6, 100, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        this.renderBackground(g);
        List<ShopCatalog.Entry> list = ShopCatalog.SHOPS.get(shop);
        int top = this.height / 2 - (list.size() * 24) / 2;
        g.drawCenteredString(this.font, this.title, this.width / 2, top - 22, 0xFFFFFF);
        int have = Minecraft.getInstance().player == null ? 0 : ShopCatalog.count(Minecraft.getInstance().player, Items.EMERALD);
        g.drawCenteredString(this.font, Component.translatable("gui.viperr.emeralds", have), this.width / 2, top - 10, 0x55FF55);
        super.render(g, mouseX, mouseY, partial);
        for (int i = 0; i < list.size(); i++) {
            g.renderItem(new ItemStack(list.get(i).item().get()), this.width / 2 - 114, top + 6 + i * 24 + 2);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
