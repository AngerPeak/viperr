package com.viperr.client;

import com.viperr.Tracks;
import com.viperr.registry.ModSounds;
import com.viperr.world.HallLayout;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;

/** What the client knows about the show: current track and the sound instance playing it. */
public final class ClientHallState {
    public static int track = -1;
    private static boolean needStart = false;
    private static SoundInstance current;

    private ClientHallState() {}

    public static boolean inHall() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level != null && mc.level.dimension().equals(HallLayout.HALL);
    }

    public static void setTrack(int index) {
        stop();
        track = index;
        needStart = index >= 0 && index < Tracks.COUNT;
    }

    private static void stop() {
        if (current != null) {
            Minecraft.getInstance().getSoundManager().stop(current);
            current = null;
        }
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (!inHall()) {
            stop();
            track = -1;
            needStart = false;
            return;
        }
        // no vanilla background music inside the hall
        mc.getMusicManager().stopPlaying();
        if (needStart && track >= 0) {
            needStart = false;
            current = SimpleSoundInstance.forUI(ModSounds.TRACKS.get(track).get(), 1.0F, 1.0F);
            mc.getSoundManager().play(current);
        }
    }
}
