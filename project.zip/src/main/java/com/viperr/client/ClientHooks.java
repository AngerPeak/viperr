package com.viperr.client;

import net.minecraft.client.Minecraft;

/** Everything the common code needs from the client side (called through DistExecutor only). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openDj() {
        Minecraft.getInstance().setScreen(new DjScreen());
    }

    public static void openShop(int shop) {
        Minecraft.getInstance().setScreen(new ShopScreen(shop));
    }

    public static void setTrack(int index) {
        ClientHallState.setTrack(index);
    }
}
