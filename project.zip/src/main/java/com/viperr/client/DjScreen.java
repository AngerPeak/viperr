package com.viperr.client;

import com.viperr.Tracks;
import com.viperr.network.ModNetwork;
import com.viperr.network.SelectTrackPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class DjScreen extends Screen {
    public DjScreen() {
        super(Component.translatable("gui.viperr.dj"));
    }

    @Override
    protected void init() {
        int y = this.height / 2 - (Tracks.COUNT * 24) / 2 + 6;
        for (int i = 0; i < Tracks.COUNT; i++) {
            final int idx = i;
            String label = (ClientHallState.track == i ? "\u25B6 " : "") + (i + 1) + ". " + Tracks.NAMES[i];
            this.addRenderableWidget(Button.builder(Component.literal(label), b -> {
                ModNetwork.CHANNEL.sendToServer(new SelectTrackPacket(idx));
                this.onClose();
            }).bounds(this.width / 2 - 100, y + i * 24, 200, 20).build());
        }
        this.addRenderableWidget(Button.builder(Component.translatable("gui.viperr.close"), b -> this.onClose())
                .bounds(this.width / 2 - 50, y + Tracks.COUNT * 24 + 6, 100, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - (Tracks.COUNT * 24) / 2 - 20, 0xFFFFFF);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
