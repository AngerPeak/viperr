package com.viperr.client;

import com.viperr.entity.ViperrNpc;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/** Player-shaped model with custom poses: dancing fans, singing artists, slouching bums. */
public class NpcModel extends PlayerModel<ViperrNpc> {
    public NpcModel(ModelPart root) {
        super(root, false);
    }

    @Override
    public void setupAnim(ViperrNpc e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        super.setupAnim(e, limbSwing, limbSwingAmount, age, yaw, pitch);
        float t = age * 0.55F + e.getId() * 1.7F;
        switch (e.getRole()) {
            case FAN -> {
                float beat = Mth.sin(t * 1.2F);
                this.rightArm.xRot = -2.7F + beat * 0.5F;
                this.rightArm.yRot = 0.0F;
                this.rightArm.zRot = 0.35F + Mth.cos(t) * 0.35F;
                this.leftArm.xRot = -2.7F - beat * 0.5F;
                this.leftArm.yRot = 0.0F;
                this.leftArm.zRot = -0.35F - Mth.cos(t) * 0.35F;
                this.head.xRot = 0.35F + Mth.sin(t * 2.0F) * 0.45F;
            }
            case BUM -> {
                this.head.xRot = 0.55F + Mth.sin(age * 0.04F) * 0.12F;
                this.rightArm.xRot = -0.25F + Mth.sin(age * 0.07F) * 0.1F;
                this.leftArm.xRot = -0.15F - Mth.sin(age * 0.05F) * 0.1F;
            }
            case KAI_ANGEL, NINE_MICE -> {
                this.rightArm.xRot = -1.75F;
                this.rightArm.yRot = -0.45F;
                this.rightArm.zRot = 0.0F;
                this.leftArm.xRot = -0.4F + Mth.sin(t) * 0.9F;
                this.leftArm.zRot = -0.3F - 0.3F * Mth.sin(t * 0.5F);
                this.head.xRot = -0.25F + Mth.sin(t * 0.5F) * 0.2F;
            }
            case FACE_CONTROL -> {
                if (e.isAggressive()) {
                    this.rightArm.xRot = -1.5F + Mth.sin(age * 0.9F) * 0.3F;
                    this.leftArm.xRot = -1.5F - Mth.sin(age * 0.9F) * 0.3F;
                } else {
                    this.rightArm.xRot = -0.85F;
                    this.rightArm.yRot = -0.5F;
                    this.leftArm.xRot = -0.85F;
                    this.leftArm.yRot = 0.5F;
                }
            }
            default -> {
            }
        }
        this.hat.copyFrom(this.head);
        this.leftSleeve.copyFrom(this.leftArm);
        this.rightSleeve.copyFrom(this.rightArm);
    }
}
