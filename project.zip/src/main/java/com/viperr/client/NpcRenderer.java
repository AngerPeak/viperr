package com.viperr.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.viperr.entity.ViperrNpc;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class NpcRenderer extends HumanoidMobRenderer<ViperrNpc, NpcModel> {
    public NpcRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new NpcModel(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(ViperrNpc entity) {
        return entity.getTexture();
    }

    @Override
    protected void setupRotations(ViperrNpc entity, PoseStack poseStack, float ageInTicks, float rotationYaw, float partialTicks) {
        super.setupRotations(entity, poseStack, ageInTicks, rotationYaw + entity.getSpin(ageInTicks), partialTicks);
    }
}
