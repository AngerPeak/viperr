package com.viperr.network;

import com.viperr.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: which track is playing right now (-1 = nothing). */
public class TrackPacket {
    public final int index;

    public TrackPacket(int index) {
        this.index = index;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(index);
    }

    public static TrackPacket decode(FriendlyByteBuf buf) {
        return new TrackPacket(buf.readInt());
    }

    public static void handle(TrackPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.setTrack(msg.index)));
        ctx.get().setPacketHandled(true);
    }
}
