package com.viperr.network;

import com.viperr.Viperr;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Viperr.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, TrackPacket.class, TrackPacket::encode, TrackPacket::decode, TrackPacket::handle);
        CHANNEL.registerMessage(id++, SelectTrackPacket.class, SelectTrackPacket::encode, SelectTrackPacket::decode, SelectTrackPacket::handle);
        CHANNEL.registerMessage(id++, BuyPacket.class, BuyPacket::encode, BuyPacket::decode, BuyPacket::handle);
    }
}
