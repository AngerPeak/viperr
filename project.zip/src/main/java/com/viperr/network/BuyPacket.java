package com.viperr.network;

import com.viperr.shop.ShopCatalog;
import com.viperr.world.HallLayout;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.List;
import java.util.function.Supplier;

/** Client -> server: buy something at a bar / kiosk. */
public class BuyPacket {
    public final int shop;
    public final int entry;

    public BuyPacket(int shop, int entry) {
        this.shop = shop;
        this.entry = entry;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(shop);
        buf.writeInt(entry);
    }

    public static BuyPacket decode(FriendlyByteBuf buf) {
        return new BuyPacket(buf.readInt(), buf.readInt());
    }

    public static void handle(BuyPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            if (!player.level().dimension().equals(HallLayout.HALL)) return;
            if (msg.shop < 0 || msg.shop >= ShopCatalog.SHOPS.size()) return;
            List<ShopCatalog.Entry> list = ShopCatalog.SHOPS.get(msg.shop);
            if (msg.entry < 0 || msg.entry >= list.size()) return;
            ShopCatalog.Entry e = list.get(msg.entry);
            if (ShopCatalog.pay(player, e.price())) {
                ShopCatalog.give(player, new ItemStack(e.item().get()));
                player.displayClientMessage(Component.translatable("message.viperr.bought"), true);
            } else {
                player.displayClientMessage(Component.translatable("message.viperr.no_money", e.price()), true);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
