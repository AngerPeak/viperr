package com.viperr.network;

import com.viperr.Tracks;
import com.viperr.world.HallLayout;
import com.viperr.world.HallManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: DJ picked a track. */
public class SelectTrackPacket {
    public final int index;

    public SelectTrackPacket(int index) {
        this.index = index;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(index);
    }

    public static SelectTrackPacket decode(FriendlyByteBuf buf) {
        return new SelectTrackPacket(buf.readInt());
    }

    public static void handle(SelectTrackPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            if (!(player.level() instanceof ServerLevel level)) return;
            if (!level.dimension().equals(HallLayout.HALL)) return;
            if (msg.index < 0 || msg.index >= Tracks.COUNT) return;
            HallManager.setTrack(level, msg.index);
        });
        ctx.get().setPacketHandled(true);
    }
}
