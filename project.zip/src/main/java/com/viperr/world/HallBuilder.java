package com.viperr.world;

import com.viperr.ModConfigs;
import com.viperr.block.DiscoBlock;
import com.viperr.entity.NpcRole;
import com.viperr.entity.ViperrNpc;
import com.viperr.registry.ModBlocks;
import com.viperr.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CandleBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LayeredCauldronBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.entity.EntityTypeTest;

/** Builds the whole concert hall with code the first time somebody enters the dimension. */
public final class HallBuilder {
    private static final int F = HallLayout.FLOOR_Y;
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    private final ServerLevel level;
    private final RandomSource rnd = RandomSource.create(1337L);
    private final BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();

    private HallBuilder(ServerLevel level) {
        this.level = level;
    }

    // ------------------------------------------------------------------ entry points

    public static void ensureBuilt(ServerLevel level) {
        HallData data = HallData.get(level);
        if (data.built) return;
        new HallBuilder(level).buildAll();
        data.built = true;
        data.setDirty();
    }

    public static void rebuild(ServerLevel level) {
        for (ViperrNpc npc : level.getEntities(EntityTypeTest.forClass(ViperrNpc.class), e -> true)) {
            npc.discard();
        }
        HallBuilder b = new HallBuilder(level);
        b.clearAll();
        b.buildAll();
        HallData data = HallData.get(level);
        data.built = true;
        data.setDirty();
    }

    private void buildAll() {
        shell();
        lobby();
        portal();
        danceFloor();
        stage();
        screen();
        ceilingRig();
        djBooth();
        toilets();
        shop();
        populate();
    }

    // ------------------------------------------------------------------ helpers

    private static BlockState s(Block b) {
        return b.defaultBlockState();
    }

    private void set(int x, int y, int z, BlockState state) {
        level.setBlock(mp.set(x, y, z), state, FLAGS);
    }

    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++)
                    set(x, y, z, state);
    }

    private BlockState pick(Block... blocks) {
        return blocks[rnd.nextInt(blocks.length)].defaultBlockState();
    }

    private void clearAll() {
        BlockState air = s(Blocks.AIR);
        for (int x = HallLayout.MIN_X - 3; x <= HallLayout.MAX_X + 3; x++)
            for (int y = F - 3; y <= F + HallLayout.HEIGHT + 3; y++)
                for (int z = HallLayout.MIN_Z - 3; z <= HallLayout.MAX_Z + 3; z++) {
                    mp.set(x, y, z);
                    if (!level.getBlockState(mp).isAir()) level.setBlock(mp, air, FLAGS);
                }
    }

    // ------------------------------------------------------------------ building

    private void shell() {
        int x1 = HallLayout.MIN_X - 1, x2 = HallLayout.MAX_X + 1;
        int z1 = HallLayout.MIN_Z - 1, z2 = HallLayout.MAX_Z + 1;
        int top = F + HallLayout.HEIGHT;

        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                set(x, F - 1, z, pick(Blocks.POLISHED_BLACKSTONE, Blocks.POLISHED_BLACKSTONE, Blocks.POLISHED_BLACKSTONE,
                        Blocks.BLACKSTONE, Blocks.DEEPSLATE_TILES));
                set(x, top, z, s(Blocks.BLACK_CONCRETE));
            }
        BlockState wall = s(Blocks.BLACK_CONCRETE);
        fill(x1, F, z1, x1, top - 1, z2, wall);
        fill(x2, F, z1, x2, top - 1, z2, wall);
        fill(x1, F, z1, x2, top - 1, z1, wall);
        fill(x1, F, z2, x2, top - 1, z2, wall);

        // neon strips on the side walls
        BlockState neon = s(Blocks.CRYING_OBSIDIAN);
        for (int z = 12; z <= 100; z += 8) {
            fill(x1, F + 3, z, x1, F + 16, z, neon);
            fill(x2, F + 3, z, x2, F + 16, z, neon);
        }
        // neon line along the walls
        fill(x1, F + 18, z1, x1, F + 18, z2, s(Blocks.PEARLESCENT_FROGLIGHT));
        fill(x2, F + 18, z1, x2, F + 18, z2, s(Blocks.PEARLESCENT_FROGLIGHT));
    }

    private void lobby() {
        // velvet rope barrier with a gap in the middle (x -2..2)
        BlockState glass = s(Blocks.BLACK_STAINED_GLASS);
        for (int x = HallLayout.MIN_X; x <= HallLayout.MAX_X; x++) {
            if (x >= -2 && x <= 2) continue;
            set(x, F, 8, s(Blocks.BLACK_CONCRETE));
            set(x, F + 1, 8, glass);
            set(x, F + 2, 8, glass);
        }
        // red carpet from the portal to the face control
        fill(-1, F, 3, 1, F, 7, s(Blocks.RED_CARPET));
        // lobby lights
        for (int x = -32; x <= 32; x += 16) {
            set(x, F + HallLayout.HEIGHT - 1, 4, s(Blocks.REDSTONE_LAMP).setValue(net.minecraft.world.level.block.RedstoneLampBlock.LIT, true));
        }
        set(-3, F + 3, 8, s(Blocks.OCHRE_FROGLIGHT));
        set(3, F + 3, 8, s(Blocks.OCHRE_FROGLIGHT));
    }

    private void portal() {
        BlockState frame = s(ModBlocks.VIPERR_BLOCK.get());
        int z = 1;
        fill(-2, F - 1, z, 2, F - 1, z, frame);
        fill(-2, F + 3, z, 2, F + 3, z, frame);
        fill(-2, F, z, -2, F + 2, z, frame);
        fill(2, F, z, 2, F + 2, z, frame);
        BlockState portal = s(ModBlocks.PORTAL.get()).setValue(com.viperr.block.ViperrPortalBlock.AXIS, net.minecraft.core.Direction.Axis.X);
        fill(-1, F, z, 1, F + 2, z, portal);
    }

    private void danceFloor() {
        BlockState base = s(ModBlocks.DISCO_FLOOR.get());
        for (int x = HallLayout.DF_X1; x <= HallLayout.DF_X2; x++)
            for (int z = HallLayout.DF_Z1; z <= HallLayout.DF_Z2; z++)
                set(x, F - 1, z, base.setValue(DiscoBlock.COLOR, Math.floorMod(((x >> 2) ^ (z >> 2)), 8)));
        BlockState border = s(Blocks.CRYING_OBSIDIAN);
        fill(HallLayout.DF_X1 - 1, F - 1, HallLayout.DF_Z1 - 1, HallLayout.DF_X2 + 1, F - 1, HallLayout.DF_Z1 - 1, border);
        fill(HallLayout.DF_X1 - 1, F - 1, HallLayout.DF_Z2 + 1, HallLayout.DF_X2 + 1, F - 1, HallLayout.DF_Z2 + 1, border);
        fill(HallLayout.DF_X1 - 1, F - 1, HallLayout.DF_Z1, HallLayout.DF_X1 - 1, F - 1, HallLayout.DF_Z2, border);
        fill(HallLayout.DF_X2 + 1, F - 1, HallLayout.DF_Z1, HallLayout.DF_X2 + 1, F - 1, HallLayout.DF_Z2, border);
    }

    private void stage() {
        int x1 = HallLayout.STAGE_X1, x2 = HallLayout.STAGE_X2, z1 = HallLayout.STAGE_Z1, z2 = HallLayout.STAGE_Z2;
        fill(x1, F, z1, x2, F, z2, s(Blocks.BLACK_CONCRETE));
        fill(x1, F + 1, z1, x2, F + 1, z2, s(Blocks.POLISHED_BLACKSTONE));
        fill(x1, F + 1, z1, x2, F + 1, z1, s(Blocks.SEA_LANTERN));
        // smoke / pyro machines
        for (int x : HallLayout.SMOKE_X) {
            set(x, F + 2, HallLayout.SMOKE_Z, s(Blocks.BLAST_FURNACE));
        }
        // speaker towers
        for (int sx : new int[]{-25, 25}) {
            for (int z = 86; z <= 88; z++) {
                for (int y = F; y <= F + 5; y++) {
                    set(sx, y, z, (y == F + 1 || y == F + 3) ? s(Blocks.NOTE_BLOCK) : s(Blocks.BLACK_CONCRETE));
                }
            }
        }
    }

    private void screen() {
        int z = HallLayout.MAX_Z + 1;
        BlockState glow = s(Blocks.PEARLESCENT_FROGLIGHT);
        fill(-20, F + 5, z, 20, F + 5, z, glow);
        fill(-20, F + 18, z, 20, F + 18, z, glow);
        fill(-20, F + 5, z, -20, F + 18, z, glow);
        fill(20, F + 5, z, 20, F + 18, z, glow);
        fill(-19, F + 6, z, 19, F + 17, z, s(Blocks.BLACK_CONCRETE));
    }

    private void ceilingRig() {
        int y = F + HallLayout.HEIGHT - 1;
        BlockState beam = s(Blocks.BLACK_CONCRETE);
        for (int z = 20; z <= 80; z += 10) fill(-26, y, z, 26, y, z, beam);
        fill(-22, F + 16, 95, 22, F + 16, 95, beam);
        fill(-22, F + 16, 100, 22, F + 16, 100, beam);
        BlockState lamp = s(ModBlocks.PARTY_LAMP.get());
        for (int[] p : HallLayout.lampPositions()) {
            set(p[0], p[1], p[2], lamp);
        }
    }

    private void djBooth() {
        int x1 = -8, x2 = 8, z1 = 25, z2 = HallLayout.DJ_Z;
        BlockState black = s(Blocks.BLACK_CONCRETE);
        // walls: back and sides (door on the left side)
        fill(x1, F, z1, x2, F + 2, z1, black);
        fill(x1, F, z1, x1, F + 2, z2, black);
        fill(x2, F, z1, x2, F + 2, z2, black);
        fill(x1, F, 29, x1, F + 1, 30, s(Blocks.AIR));
        // roof
        fill(x1, F + 3, z1, x2, F + 3, z2, black);
        set(-6, F + 3, 29, s(Blocks.PEARLESCENT_FROGLIGHT));
        set(0, F + 3, 29, s(Blocks.VERDANT_FROGLIGHT));
        set(6, F + 3, 29, s(Blocks.PEARLESCENT_FROGLIGHT));
        // floor of the booth
        fill(x1 + 1, F - 1, z1 + 1, x2 - 1, F - 1, z2, s(Blocks.PURPLE_CONCRETE));
        // counter facing the dance floor
        fill(x1, F, z2, x2, F, z2, black);
        set(HallLayout.DJ_X, F, HallLayout.DJ_Z, s(ModBlocks.DJ_CONSOLE.get()));
        set(-4, F + 1, z2, s(Blocks.JUKEBOX));
        set(4, F + 1, z2, s(Blocks.JUKEBOX));
        set(-2, F + 1, z2, s(Blocks.NOTE_BLOCK));
        set(2, F + 1, z2, s(Blocks.NOTE_BLOCK));
        set(-6, F + 1, z2, s(Blocks.REDSTONE_LAMP));
        set(6, F + 1, z2, s(Blocks.REDSTONE_LAMP));
        fill(x1, F + 2, z2, x2, F + 2, z2, s(Blocks.BLACK_STAINED_GLASS));
    }

    // ------------------------------------------------------------------ toilets

    private void toilets() {
        Block[] walls = {Blocks.MOSSY_STONE_BRICKS, Blocks.CRACKED_STONE_BRICKS, Blocks.STONE_BRICKS, Blocks.GREEN_TERRACOTTA, Blocks.BROWN_TERRACOTTA};
        Block[] floors = {Blocks.MUD, Blocks.COARSE_DIRT, Blocks.BROWN_TERRACOTTA, Blocks.YELLOW_TERRACOTTA, Blocks.MOSSY_COBBLESTONE,
                Blocks.GREEN_TERRACOTTA, Blocks.CRACKED_STONE_BRICKS, Blocks.GRAY_CONCRETE, Blocks.PODZOL};

        // partition with the hall (doorway z 24..26) and the outer wall
        for (int z = 9; z <= 41; z++)
            for (int y = F; y <= F + 3; y++) {
                if (!(z >= 24 && z <= 26 && y <= F + 2)) set(-26, y, z, pick(walls));
                set(-41, y, z, pick(walls));
            }
        for (int x = -40; x <= -27; x++)
            for (int y = F; y <= F + 3; y++) {
                set(x, y, 9, pick(walls));
                set(x, y, 41, pick(walls));
            }
        // low dirty ceiling and floor
        for (int x = -41; x <= -26; x++)
            for (int z = 9; z <= 41; z++) {
                set(x, F + 4, z, pick(walls));
            }
        for (int x = -40; x <= -27; x++)
            for (int z = 10; z <= 40; z++) {
                set(x, F - 1, z, pick(floors));
                int r = rnd.nextInt(100);
                if (r < 9) set(x, F, z, s(Blocks.YELLOW_CARPET));      // puddles
                else if (r < 14) set(x, F, z, s(Blocks.BROWN_CARPET)); // dirt
                else if (r < 16) set(x, F, z, s(Blocks.GREEN_CARPET)); // something green
            }

        // stalls along the west wall
        Block[] partitions = {Blocks.LIGHT_GRAY_TERRACOTTA, Blocks.GRAY_CONCRETE, Blocks.CYAN_TERRACOTTA};
        for (int k = 0; k < 8; k++) {
            int pz = 10 + 4 * k;
            for (int x = -40; x <= -37; x++)
                for (int y = F; y <= F + 2; y++)
                    set(x, y, pz, pick(partitions));
            if (k < 7) {
                set(-40, F, pz + 2, s(Blocks.WATER_CAULDRON).setValue(LayeredCauldronBlock.LEVEL, 2)); // toilet bowl
                set(-39, F, pz + 2, s(Blocks.BROWN_CARPET));
            }
        }
        // sinks at the far wall
        for (int x = -34; x <= -28; x += 2) {
            set(x, F, 40, s(Blocks.WATER_CAULDRON).setValue(LayeredCauldronBlock.LEVEL, 1));
        }
        // trash bins
        set(-27, F, 12, s(Blocks.COMPOSTER));
        set(-27, F, 38, s(Blocks.COMPOSTER));
        set(-27, F, 20, s(Blocks.COMPOSTER));
        // dim creepy light
        BlockState lantern = s(Blocks.SOUL_LANTERN).setValue(LanternBlock.HANGING, true);
        set(-32, F + 3, 14, lantern);
        set(-32, F + 3, 34, lantern);
        set(-29, F + 3, 22, lantern);
        set(-29, F + 3, 30, lantern);
        set(-35, F + 3, 25, lantern);
        // cobwebs
        for (int i = 0; i < 25; i++) {
            int x = -40 + rnd.nextInt(14);
            int z = 10 + rnd.nextInt(31);
            if (level.getBlockState(mp.set(x, F + 3, z)).isAir()) set(x, F + 3, z, s(Blocks.COBWEB));
        }
    }

    // ------------------------------------------------------------------ shop / bar

    private void shop() {
        Block[] floors = {Blocks.DARK_OAK_PLANKS, Blocks.SPRUCE_PLANKS, Blocks.DARK_OAK_PLANKS};
        BlockState wood = s(Blocks.DARK_OAK_PLANKS);
        for (int z = 9; z <= 41; z++)
            for (int y = F; y <= F + 3; y++) {
                if (!(z >= 24 && z <= 26 && y <= F + 2)) set(26, y, z, wood);
                set(41, y, z, wood);
            }
        for (int x = 27; x <= 40; x++)
            for (int y = F; y <= F + 3; y++) {
                set(x, y, 9, wood);
                set(x, y, 41, wood);
            }
        for (int x = 26; x <= 41; x++)
            for (int z = 9; z <= 41; z++)
                set(x, F + 4, z, wood);
        for (int x = 27; x <= 40; x++)
            for (int z = 10; z <= 40; z++)
                set(x, F - 1, z, pick(floors));

        // bar counter
        BlockState counter = s(Blocks.STRIPPED_DARK_OAK_LOG);
        for (int z = 11; z <= 39; z++) {
            set(34, F, z, counter);
            set(34, F + 1, z, s(Blocks.DARK_OAK_SLAB));
        }
        // shelves with bottles
        for (int z = 11; z <= 39; z++) {
            set(40, F, z, s(Blocks.BARREL));
            set(40, F + 1, z, s(Blocks.BARREL));
            set(40, F + 2, z, s(Blocks.BOOKSHELF));
        }
        // neon over the bar
        for (int z = 11; z <= 39; z += 4) {
            set(34, F + 3, z, (z % 8 == 3) ? s(Blocks.PEARLESCENT_FROGLIGHT) : s(Blocks.VERDANT_FROGLIGHT));
        }
        set(30, F + 3, 16, s(Blocks.SOUL_LANTERN).setValue(LanternBlock.HANGING, true));
        set(30, F + 3, 34, s(Blocks.SOUL_LANTERN).setValue(LanternBlock.HANGING, true));
        // standing tables
        int[][] tables = {{29, 14}, {29, 20}, {29, 30}, {29, 36}, {32, 17}, {32, 33}};
        for (int[] t : tables) {
            set(t[0], F, t[1], s(Blocks.BARREL));
            set(t[0], F + 1, t[1], s(Blocks.CANDLE).setValue(CandleBlock.LIT, true));
        }
    }

    // ------------------------------------------------------------------ crowd

    private int n(int base) {
        return Math.max(1, (int) Math.round(base * ModConfigs.CROWD.get()));
    }

    private ViperrNpc spawn(NpcRole role, double x, double y, double z, float yaw, int variant, boolean home) {
        ViperrNpc npc = ModEntities.NPC.get().create(level);
        if (npc == null) return null;
        npc.moveTo(x, y, z, yaw, 0.0F);
        npc.setYBodyRot(yaw);
        npc.setYHeadRot(yaw);
        npc.setRole(role);
        npc.setVariant(variant);
        if (home) npc.setHome(x, y, z);
        level.addFreshEntity(npc);
        return npc;
    }

    private void crowd(int count, double x1, double x2, double z1, double z2, double y, NpcRole role, int variants) {
        for (int i = 0; i < n(count); i++) {
            double x = x1 + rnd.nextDouble() * (x2 - x1);
            double z = z1 + rnd.nextDouble() * (z2 - z1);
            spawn(role, x, y, z, rnd.nextFloat() * 360.0F, rnd.nextInt(variants), true);
        }
    }

    private void populate() {
        // key characters
        spawn(NpcRole.KAI_ANGEL, -6.5, HallLayout.STAGE_Y, 97.5, 180.0F, 0, false);
        spawn(NpcRole.NINE_MICE, 6.5, HallLayout.STAGE_Y, 97.5, 180.0F, 0, false);
        // staff
        spawn(NpcRole.FACE_CONTROL, 0.5, F, 8.5, 180.0F, 0, true);
        spawn(NpcRole.BARTENDER, 35.5, F, 18.5, 90.0F, 0, true);
        spawn(NpcRole.VENDOR, 35.5, F, 30.5, 90.0F, 0, true);

        // dance floor + pit in front of the stage
        crowd(125, -19.5, 19.5, 41, 83, F, NpcRole.FAN, 6);
        crowd(22, -20, 20, 85, 89, F, NpcRole.FAN, 6);
        // lobby queue
        crowd(16, -38, -4, 1.5, 7, F, NpcRole.FAN, 6);
        crowd(16, 4, 38, 1.5, 7, F, NpcRole.FAN, 6);
        // main hall (between face control and DJ, and lounges at the sides)
        crowd(35, -24, 24, 11, 23, F, NpcRole.FAN, 6);
        crowd(14, -38, -24, 45, 100, F, NpcRole.FAN, 6);
        crowd(14, 24, 38, 45, 100, F, NpcRole.FAN, 6);
        // shop customers
        crowd(26, 27.5, 32.5, 11, 39, F, NpcRole.FAN, 6);
        // toilet regulars
        crowd(16, -36, -28, 12, 38, F, NpcRole.BUM, 3);
    }
}
