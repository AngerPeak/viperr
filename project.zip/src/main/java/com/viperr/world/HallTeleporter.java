package com.viperr.world;

import com.viperr.network.ModNetwork;
import com.viperr.network.TrackPacket;
import com.viperr.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;

public final class HallTeleporter {
    private static final String CD = "viperr_cd";
    private static final String O_DIM = "viperr_o_dim";
    private static final String O_X = "viperr_o_x";
    private static final String O_Y = "viperr_o_y";
    private static final String O_Z = "viperr_o_z";

    private HallTeleporter() {}

    public static boolean hasTicket(net.minecraft.world.entity.player.Player player) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(ModItems.TICKET.get())) return true;
        }
        return false;
    }

    /** Called every tick while the player stands inside a portal block. */
    public static void usePortal(ServerPlayer player) {
        long now = player.level().getGameTime();
        CompoundTag data = player.getPersistentData();
        if (data.getLong(CD) > now) {
            data.putLong(CD, now + 40);
            return;
        }
        data.putLong(CD, now + 100);
        final boolean inHall = player.level().dimension().equals(HallLayout.HALL);
        HallManager.defer(() -> {
            if (inHall) leaveHall(player); else enterHall(player);
        });
    }

    public static void enterHall(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) return;
        ServerLevel hall = server.getLevel(HallLayout.HALL);
        if (hall == null) {
            player.displayClientMessage(Component.literal("VIPERR HALL dimension is missing!"), false);
            return;
        }
        CompoundTag data = player.getPersistentData();
        if (!player.level().dimension().equals(HallLayout.HALL)) {
            data.putString(O_DIM, player.level().dimension().location().toString());
            data.putDouble(O_X, player.getX());
            data.putDouble(O_Y, player.getY());
            data.putDouble(O_Z, player.getZ());
        }
        HallBuilder.ensureBuilt(hall);
        player.teleportTo(hall, HallLayout.SPAWN_X, HallLayout.SPAWN_Y, HallLayout.SPAWN_Z, 0.0F, 0.0F);
        data.putLong(CD, hall.getGameTime() + 100);
        HallManager.onEnter(player);
    }

    public static void leaveHall(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) return;
        CompoundTag data = player.getPersistentData();
        ServerLevel dest = null;
        if (data.contains(O_DIM)) {
            ResourceLocation rl = ResourceLocation.tryParse(data.getString(O_DIM));
            if (rl != null) dest = server.getLevel(ResourceKey.create(Registries.DIMENSION, rl));
        }
        double x, y, z;
        if (dest == null) {
            dest = server.overworld();
            BlockPos sp = dest.getSharedSpawnPos();
            x = sp.getX() + 0.5; y = sp.getY(); z = sp.getZ() + 0.5;
        } else {
            x = data.getDouble(O_X); y = data.getDouble(O_Y); z = data.getDouble(O_Z);
        }
        player.teleportTo(dest, x, y, z, player.getYRot(), player.getXRot());
        data.putLong(CD, dest.getGameTime() + 100);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new TrackPacket(-1));
    }
}
