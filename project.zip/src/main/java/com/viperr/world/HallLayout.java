package com.viperr.world;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/** All coordinates of VIPERR HALL in one place. */
public final class HallLayout {
    public static final ResourceKey<Level> HALL = ResourceKey.create(Registries.DIMENSION, new ResourceLocation("viperr", "hall"));

    public static final int FLOOR_Y = 40;               // y where entities stand
    public static final int MIN_X = -40, MAX_X = 40;    // interior
    public static final int MIN_Z = 0, MAX_Z = 103;
    public static final int HEIGHT = 20;                // ceiling block is at FLOOR_Y + HEIGHT

    public static final double SPAWN_X = 0.5, SPAWN_Y = FLOOR_Y, SPAWN_Z = 4.5;
    /** Everyone who is further than this without a ticket gets chased by the face control. */
    public static final double CHECK_Z = 9.0;

    // dance floor (tiles lie at FLOOR_Y - 1)
    public static final int DF_X1 = -20, DF_X2 = 20, DF_Z1 = 40, DF_Z2 = 84;

    // stage
    public static final int STAGE_X1 = -22, STAGE_X2 = 22, STAGE_Z1 = 90, STAGE_Z2 = 103;
    public static final int STAGE_Y = FLOOR_Y + 2;      // stage surface (entities stand here)

    // area where the artists walk
    public static final int WALK_X1 = -18, WALK_X2 = 18, WALK_Z1 = 93, WALK_Z2 = 101;

    // DJ booth
    public static final int DJ_X = 0, DJ_Z = 33;

    // big screen (text is drawn on the plane z = SCREEN_Z)
    public static final double SCREEN_CX = 0.5;
    public static final double SCREEN_CY = FLOOR_Y + 12.0;
    public static final double SCREEN_Z = MAX_Z + 1.0;

    public static final int[] SMOKE_X = {-20, -8, 8, 20};
    public static final int SMOKE_Z = 92;

    private HallLayout() {}

    /** Positions of all coloured party lamps (x, y, z). */
    public static List<int[]> lampPositions() {
        List<int[]> list = new ArrayList<>();
        for (int x = -24; x <= 24; x += 6) {
            for (int z = 20; z <= 100; z += 10) {
                if (z >= 88) continue; // stage has its own lamps
                list.add(new int[]{x, FLOOR_Y + 18, z});
            }
        }
        for (int x = -20; x <= 20; x += 5) {
            list.add(new int[]{x, FLOOR_Y + 15, 95});
            list.add(new int[]{x, FLOOR_Y + 15, 100});
        }
        return list;
    }
}
