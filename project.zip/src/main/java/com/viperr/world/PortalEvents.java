package com.viperr.world;

import com.viperr.Viperr;
import com.viperr.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Lights the portal when you use flint and steel on a VIPERR block frame. */
@Mod.EventBusSubscriber(modid = Viperr.MODID)
public class PortalEvents {
    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickBlock event) {
        ItemStack stack = event.getItemStack();
        if (!stack.is(Items.FLINT_AND_STEEL)) return;
        if (event.getFace() == null) return;
        Level level = event.getLevel();
        if (!level.getBlockState(event.getPos()).is(ModBlocks.VIPERR_BLOCK.get())) return;

        BlockPos target = event.getPos().relative(event.getFace());
        PortalShape shape = PortalShape.find(level, target);
        if (shape == null) return;

        if (!level.isClientSide) {
            shape.createPortal(level);
            level.playSound(null, target, SoundEvents.FLINTANDSTEEL_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
            level.playSound(null, target, SoundEvents.END_PORTAL_SPAWN, SoundSource.BLOCKS, 0.4F, 1.5F);
            stack.hurtAndBreak(1, event.getEntity(), p -> p.broadcastBreakEvent(event.getHand()));
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide));
    }
}
