package com.viperr.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

public class HallData extends SavedData {
    public boolean built = false;

    public static HallData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(HallData::load, HallData::new, "viperr_hall");
    }

    public static HallData load(CompoundTag tag) {
        HallData d = new HallData();
        d.built = tag.getBoolean("built");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("built", built);
        return tag;
    }
}
