package com.viperr.world;

import com.viperr.block.ViperrPortalBlock;
import com.viperr.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/** Finds a rectangular frame of VIPERR blocks (min 2x3 inside, max 21x21) around an empty position. */
public final class PortalShape {
    private static final int MIN_W = 2, MAX_W = 21, MIN_H = 3, MAX_H = 21;

    private final Direction.Axis axis;
    private final List<BlockPos> inside;

    private PortalShape(Direction.Axis axis, List<BlockPos> inside) {
        this.axis = axis;
        this.inside = inside;
    }

    public static PortalShape find(Level level, BlockPos start) {
        PortalShape s = detect(level, start, Direction.Axis.X);
        if (s == null) s = detect(level, start, Direction.Axis.Z);
        return s;
    }

    public void createPortal(Level level) {
        BlockState state = ModBlocks.PORTAL.get().defaultBlockState().setValue(ViperrPortalBlock.AXIS, axis);
        for (BlockPos p : inside) {
            level.setBlock(p, state, 2 | 16);
        }
    }

    private static boolean empty(BlockState s) {
        return s.isAir() || s.is(BlockTags.FIRE);
    }

    private static boolean frame(Level level, BlockPos p) {
        return level.getBlockState(p).is(ModBlocks.VIPERR_BLOCK.get());
    }

    private static PortalShape detect(Level level, BlockPos start, Direction.Axis axis) {
        Direction right = axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
        Direction left = right.getOpposite();

        if (!empty(level.getBlockState(start))) return null;

        BlockPos p = start;
        int guard = 0;
        while (guard++ < MAX_H && empty(level.getBlockState(p.below()))) p = p.below();
        if (!frame(level, p.below())) return null;

        guard = 0;
        while (guard++ < MAX_W && empty(level.getBlockState(p.relative(left)))) p = p.relative(left);
        if (!frame(level, p.relative(left))) return null;

        BlockPos bl = p; // bottom-left inner position

        int w = 0;
        while (w <= MAX_W && empty(level.getBlockState(bl.relative(right, w)))) {
            if (!frame(level, bl.relative(right, w).below())) return null;
            w++;
        }
        if (w < MIN_W || w > MAX_W) return null;
        if (!frame(level, bl.relative(right, w))) return null;

        int h = 0;
        while (true) {
            if (h > MAX_H) return null;
            boolean allEmpty = true;
            boolean allFrame = true;
            for (int i = 0; i < w; i++) {
                BlockState s = level.getBlockState(bl.relative(right, i).above(h));
                if (!empty(s)) allEmpty = false;
                if (!s.is(ModBlocks.VIPERR_BLOCK.get())) allFrame = false;
            }
            if (allEmpty) {
                if (!frame(level, bl.relative(left).above(h)) || !frame(level, bl.relative(right, w).above(h))) return null;
                h++;
            } else if (allFrame) {
                break;
            } else {
                return null;
            }
        }
        if (h < MIN_H) return null;

        List<BlockPos> inside = new ArrayList<>();
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                inside.add(bl.relative(right, i).above(j));
            }
        }
        return new PortalShape(axis, inside);
    }
}
