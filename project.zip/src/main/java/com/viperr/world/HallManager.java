package com.viperr.world;

import com.viperr.Tracks;
import com.viperr.Viperr;
import com.viperr.block.DiscoBlock;
import com.viperr.network.ModNetwork;
import com.viperr.network.TrackPacket;
import com.viperr.registry.ModBlocks;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;

/** Runs the show: track switching, dance floor, lamps, smoke, pyro, lightning, fireworks and lasers. */
@Mod.EventBusSubscriber(modid = Viperr.MODID)
public final class HallManager {
    private static final int F = HallLayout.FLOOR_Y;
    private static final Queue<Runnable> DEFERRED = new ArrayDeque<>();
    private static final Map<UUID, Integer> TITLES = new HashMap<>();
    private static final RandomSource RND = RandomSource.create();

    private static final Vector3f[] LASER_COLORS = {
            new Vector3f(1.0F, 0.0F, 0.4F), new Vector3f(0.2F, 0.4F, 1.0F), new Vector3f(0.1F, 1.0F, 0.4F),
            new Vector3f(0.7F, 0.1F, 1.0F), new Vector3f(1.0F, 0.9F, 0.1F), new Vector3f(1.0F, 1.0F, 1.0F)
    };
    private static final int[] FIREWORK_COLORS = {0xFF1177, 0x3366FF, 0x22FF66, 0xAA22FF, 0xFFE62E, 0xFFFFFF, 0xFF3311};

    private static int track = 0;
    private static int elapsed = 0;
    private static int tick = 0;
    private static int step = 0;

    private HallManager() {}

    public static void defer(Runnable r) {
        DEFERRED.add(r);
    }

    // ------------------------------------------------------------------ tracks

    public static int currentTrack() {
        return track;
    }

    public static void setTrack(ServerLevel level, int index) {
        track = index;
        elapsed = 0;
        ModNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(() -> HallLayout.HALL), new TrackPacket(index));
    }

    /** Called right after a player was teleported into the hall (or logged in there). */
    public static void onEnter(ServerPlayer player) {
        if (player.level() instanceof ServerLevel lvl && lvl.players().size() <= 1) {
            elapsed = 0;
        }
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new TrackPacket(track));
        TITLES.put(player.getUUID(), 12);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp && sp.level().dimension().equals(HallLayout.HALL)) {
            onEnter(sp);
        }
    }

    // ------------------------------------------------------------------ main tick

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Runnable r;
        while ((r = DEFERRED.poll()) != null) {
            try {
                r.run();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        if (!TITLES.isEmpty()) {
            Iterator<Map.Entry<UUID, Integer>> it = TITLES.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Integer> e = it.next();
                int left = e.getValue() - 1;
                if (left > 0) {
                    e.setValue(left);
                    continue;
                }
                it.remove();
                ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
                if (p != null && p.level().dimension().equals(HallLayout.HALL)) {
                    p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 30));
                    p.connection.send(new ClientboundSetTitleTextPacket(
                            Component.literal("VIPERR HALL").withStyle(ChatFormatting.BOLD, ChatFormatting.LIGHT_PURPLE)));
                }
            }
        }

        ServerLevel hall = server.getLevel(HallLayout.HALL);
        if (hall == null) return;
        if (hall.players().isEmpty()) {
            elapsed = 0;
            return;
        }
        tickHall(hall);
    }

    private static void tickHall(ServerLevel level) {
        tick++;
        elapsed++;
        if (elapsed >= (Tracks.SECONDS[track] + 1) * 20) {
            setTrack(level, (track + 1) % Tracks.COUNT);
        }

        if (tick % 8 == 0) {
            step++;
            recolor(level);
        }
        if (tick % 4 == 0) {
            smoke(level);
            lasers(level);
        }
        if (tick % 10 == 0) {
            floorFog(level);
        }
        if (tick % 90 == 0) {
            pyro(level);
        }
        if (tick % 50 == 0 && RND.nextInt(3) != 0) {
            lightning(level);
        }
        if (tick % 40 == 0) {
            fireworks(level);
        }
    }

    // ------------------------------------------------------------------ effects

    private static void recolor(ServerLevel level) {
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        BlockState floor = ModBlocks.DISCO_FLOOR.get().defaultBlockState();
        for (int x = HallLayout.DF_X1; x <= HallLayout.DF_X2; x++) {
            for (int z = HallLayout.DF_Z1; z <= HallLayout.DF_Z2; z++) {
                mp.set(x, F - 1, z);
                if (!level.hasChunkAt(mp)) continue;
                int c = Math.floorMod(((x >> 2) ^ (z >> 2)) + step, 8);
                BlockState want = floor.setValue(DiscoBlock.COLOR, c);
                if (level.getBlockState(mp) != want) level.setBlock(mp, want, 2 | 16);
            }
        }
        BlockState lamp = ModBlocks.PARTY_LAMP.get().defaultBlockState();
        List<int[]> lamps = HallLayout.lampPositions();
        for (int i = 0; i < lamps.size(); i++) {
            int[] p = lamps.get(i);
            mp.set(p[0], p[1], p[2]);
            if (!level.hasChunkAt(mp)) continue;
            BlockState want = lamp.setValue(DiscoBlock.COLOR, Math.floorMod(i * 3 + step, 8));
            if (level.getBlockState(mp) != want) level.setBlock(mp, want, 2 | 16);
        }
    }

    private static void smoke(ServerLevel level) {
        for (int x : HallLayout.SMOKE_X) {
            level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, x + 0.5, HallLayout.STAGE_Y + 1.2, HallLayout.SMOKE_Z + 0.5,
                    2, 0.2, 0.0, 0.2, 0.03);
        }
    }

    private static void floorFog(ServerLevel level) {
        for (int i = 0; i < 3; i++) {
            double x = HallLayout.DF_X1 + RND.nextInt(HallLayout.DF_X2 - HallLayout.DF_X1);
            double z = HallLayout.DF_Z1 + RND.nextInt(HallLayout.DF_Z2 - HallLayout.DF_Z1);
            level.sendParticles(ParticleTypes.CLOUD, x, F + 0.2, z, 6, 3.0, 0.1, 3.0, 0.01);
        }
    }

    private static void pyro(ServerLevel level) {
        for (int x : HallLayout.SMOKE_X) {
            for (int i = 0; i < 14; i++) {
                level.sendParticles(ParticleTypes.FLAME, x + 0.5, HallLayout.STAGE_Y + 1.5, HallLayout.SMOKE_Z + 0.5,
                        0, (RND.nextDouble() - 0.5) * 0.15, 1.0, (RND.nextDouble() - 0.5) * 0.15, 0.35 + RND.nextDouble() * 0.2);
            }
            for (int i = 0; i < 10; i++) {
                level.sendParticles(ParticleTypes.FIREWORK, x + 0.5, HallLayout.STAGE_Y + 1.5, HallLayout.SMOKE_Z + 0.5,
                        0, (RND.nextDouble() - 0.5) * 0.4, 1.0, (RND.nextDouble() - 0.5) * 0.4, 0.4);
            }
        }
    }

    private static void lightning(ServerLevel level) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) return;
        double x = -20 + RND.nextInt(41);
        double z = 58 + RND.nextInt(42);
        bolt.moveTo(x, HallLayout.FLOOR_Y + (z > 89 ? 2 : 0), z);
        bolt.setVisualOnly(true);
        level.addFreshEntity(bolt);
    }

    private static void fireworks(ServerLevel level) {
        int n = 1 + RND.nextInt(3);
        for (int i = 0; i < n; i++) {
            ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
            CompoundTag fw = rocket.getOrCreateTagElement("Fireworks");
            fw.putByte("Flight", (byte) 1);
            ListTag explosions = new ListTag();
            CompoundTag ex = new CompoundTag();
            ex.putByte("Type", (byte) RND.nextInt(5));
            ex.putIntArray("Colors", new int[]{FIREWORK_COLORS[RND.nextInt(FIREWORK_COLORS.length)], FIREWORK_COLORS[RND.nextInt(FIREWORK_COLORS.length)]});
            ex.putBoolean("Flicker", true);
            ex.putBoolean("Trail", true);
            explosions.add(ex);
            fw.put("Explosions", explosions);
            double x = -18 + RND.nextInt(37);
            FireworkRocketEntity e = new FireworkRocketEntity(level, x + 0.5, HallLayout.STAGE_Y + 1.0, 91.5, rocket);
            level.addFreshEntity(e);
        }
    }

    private static void lasers(ServerLevel level) {
        double t = tick * 0.045;
        for (int i = 0; i < 5; i++) {
            double ex = -16 + i * 8 + 0.5, ey = F + 17, ez = 100.5;
            double tx = Math.sin(t * 1.3 + i * 1.7) * 26.0;
            double tz = 62.0 + Math.cos(t * 0.9 + i * 2.3) * 24.0;
            double ty = F + 1.0;
            Vector3f color = LASER_COLORS[(i + tick / 60) % LASER_COLORS.length];
            DustParticleOptions dust = new DustParticleOptions(color, 1.3F);
            int n = 32;
            for (int k = 1; k <= n; k++) {
                double f = k / (double) n;
                level.sendParticles(dust, ex + (tx - ex) * f, ey + (ty - ey) * f, ez + (tz - ez) * f, 1, 0, 0, 0, 0);
            }
        }
    }
}
