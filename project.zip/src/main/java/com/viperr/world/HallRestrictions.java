package com.viperr.world;

import com.viperr.Viperr;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Nothing can be built or broken inside the hall and nobody can leave it by walking. */
@Mod.EventBusSubscriber(modid = Viperr.MODID)
public class HallRestrictions {
    private static boolean inHall(Player p) {
        return p.level().dimension().equals(HallLayout.HALL);
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        Player p = event.getPlayer();
        if (inHall(p) && !p.isCreative()) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (event.getEntity() instanceof Player p && inHall(p) && !p.isCreative()) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onUse(PlayerInteractEvent.RightClickBlock event) {
        Player p = event.getEntity();
        if (!inHall(p) || p.isCreative()) return;
        ItemStack s = event.getItemStack();
        if (!s.isEmpty() && !s.isEdible()) {
            event.setUseItem(Event.Result.DENY);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer sp)) return;
        if (sp.tickCount % 20 != 0 || !inHall(sp)) return;
        boolean out = sp.getY() < HallLayout.FLOOR_Y - 4 || sp.getY() > HallLayout.FLOOR_Y + HallLayout.HEIGHT
                || sp.getX() < HallLayout.MIN_X - 1 || sp.getX() > HallLayout.MAX_X + 2
                || sp.getZ() < HallLayout.MIN_Z - 1 || sp.getZ() > HallLayout.MAX_Z + 2;
        if (out) {
            sp.teleportTo(HallLayout.SPAWN_X, HallLayout.SPAWN_Y, HallLayout.SPAWN_Z);
        }
    }
}
