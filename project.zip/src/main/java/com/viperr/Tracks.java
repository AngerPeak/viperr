package com.viperr;

public final class Tracks {
    public static final String[] NAMES = {
            "Fountainebleau", "Frank Ocean", "Ice & Alabaster", "Surgery", "Big City Life", "Phoenix"
    };
    /** Length of every track in seconds (used to switch to the next track automatically). */
    public static final int[] SECONDS = {134, 127, 132, 116, 159, 151};
    public static final int COUNT = NAMES.length;

    private Tracks() {}
}
