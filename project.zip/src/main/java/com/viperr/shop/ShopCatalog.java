package com.viperr.shop;

import com.viperr.registry.ModItems;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;
import java.util.function.Supplier;

public final class ShopCatalog {
    public record Entry(Supplier<? extends Item> item, int price) {}

    /** 0 = bar (alcohol), 1 = kiosk (water / food). Price is in emeralds. */
    public static final List<List<Entry>> SHOPS = List.of(
            List.of(
                    new Entry(ModItems.BEER, 1),
                    new Entry(ModItems.VODKA, 2),
                    new Entry(ModItems.WHISKEY, 3)),
            List.of(
                    new Entry(ModItems.WATER, 1),
                    new Entry(ModItems.ENERGY_DRINK, 2),
                    new Entry(ModItems.HOTDOG, 1),
                    new Entry(ModItems.BURGER, 2),
                    new Entry(ModItems.CHIPS, 1))
    );

    public static final int TICKET_PRICE = 3;

    private ShopCatalog() {}

    public static int count(Player player, Item item) {
        int total = 0;
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(item)) total += s.getCount();
        }
        return total;
    }

    public static void remove(Player player, Item item, int amount) {
        Inventory inv = player.getInventory();
        int left = amount;
        for (int i = 0; i < inv.getContainerSize() && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(item)) {
                int take = Math.min(left, s.getCount());
                s.shrink(take);
                left -= take;
            }
        }
        inv.setChanged();
    }

    public static boolean pay(Player player, int price) {
        if (count(player, Items.EMERALD) < price) return false;
        remove(player, Items.EMERALD, price);
        return true;
    }

    public static void give(Player player, ItemStack stack) {
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }
}
