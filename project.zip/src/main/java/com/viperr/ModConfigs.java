package com.viperr;

import net.minecraftforge.common.ForgeConfigSpec;

public class ModConfigs {
    public static final ForgeConfigSpec CLIENT_SPEC;
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final ForgeConfigSpec.BooleanValue STROBE;
    public static final ForgeConfigSpec.DoubleValue CROWD;

    static {
        ForgeConfigSpec.Builder c = new ForgeConfigSpec.Builder();
        STROBE = c.comment("Strobe flashes on the screen inside VIPERR HALL. Set to false if you are sensitive to flashing lights.")
                .define("strobeOverlay", true);
        CLIENT_SPEC = c.build();

        ForgeConfigSpec.Builder s = new ForgeConfigSpec.Builder();
        CROWD = s.comment("Crowd size multiplier (1.0 = about 270 NPCs). Lower it if the game lags. Applies on next hall build (/viperr rebuild).")
                .defineInRange("crowdMultiplier", 1.0D, 0.05D, 3.0D);
        COMMON_SPEC = s.build();
    }
}
