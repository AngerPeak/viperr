package com.viperr.registry;

import com.viperr.Viperr;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Viperr.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("viperr", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.viperr"))
            .icon(() -> new ItemStack(ModItems.VIPERR_DUST.get()))
            .displayItems((params, output) -> {
                for (RegistryObject<Item> item : ModItems.ITEMS.getEntries()) {
                    output.accept(item.get());
                }
            })
            .build());
}
