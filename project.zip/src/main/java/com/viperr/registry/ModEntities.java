package com.viperr.registry;

import com.viperr.Viperr;
import com.viperr.entity.ViperrNpc;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Viperr.MODID);

    public static final RegistryObject<EntityType<ViperrNpc>> NPC = ENTITIES.register("npc", () ->
            EntityType.Builder.of(ViperrNpc::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .updateInterval(2)
                    .build("npc"));
}
