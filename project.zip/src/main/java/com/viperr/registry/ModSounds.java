package com.viperr.registry;

import com.viperr.Tracks;
import com.viperr.Viperr;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Viperr.MODID);
    public static final List<RegistryObject<SoundEvent>> TRACKS = new ArrayList<>();

    static {
        for (int i = 0; i < Tracks.COUNT; i++) {
            final String name = "track_" + i;
            TRACKS.add(SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(Viperr.MODID, name))));
        }
    }
}
