package com.viperr.registry;

import com.viperr.Viperr;
import com.viperr.item.DrinkItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, Viperr.MODID);

    public static final RegistryObject<Item> VIPERR_DUST = ITEMS.register("viperr_dust", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> TICKET = ITEMS.register("viperr_ticket", () -> new Item(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> VIPERR_ORE = ITEMS.register("viperr_ore", () -> new BlockItem(ModBlocks.VIPERR_ORE.get(), new Item.Properties()));
    public static final RegistryObject<Item> VIPERR_BLOCK = ITEMS.register("viperr_block", () -> new BlockItem(ModBlocks.VIPERR_BLOCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> DJ_CONSOLE = ITEMS.register("dj_console", () -> new BlockItem(ModBlocks.DJ_CONSOLE.get(), new Item.Properties()));

    // ---- drinks ----
    public static final RegistryObject<Item> BEER = ITEMS.register("beer", () -> new DrinkItem(new Item.Properties().stacksTo(16)
            .food(new FoodProperties.Builder().nutrition(2).saturationMod(0.2F).alwaysEat()
                    .effect(() -> new MobEffectInstance(MobEffects.CONFUSION, 300, 0), 1.0F).build()), false));
    public static final RegistryObject<Item> VODKA = ITEMS.register("vodka", () -> new DrinkItem(new Item.Properties().stacksTo(16)
            .food(new FoodProperties.Builder().nutrition(1).saturationMod(0.1F).alwaysEat()
                    .effect(() -> new MobEffectInstance(MobEffects.CONFUSION, 600, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, 0), 1.0F).build()), false));
    public static final RegistryObject<Item> WHISKEY = ITEMS.register("whiskey", () -> new DrinkItem(new Item.Properties().stacksTo(16)
            .food(new FoodProperties.Builder().nutrition(1).saturationMod(0.1F).alwaysEat()
                    .effect(() -> new MobEffectInstance(MobEffects.CONFUSION, 800, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 400, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 800, 0), 1.0F).build()), false));
    public static final RegistryObject<Item> ENERGY_DRINK = ITEMS.register("energy_drink", () -> new DrinkItem(new Item.Properties().stacksTo(16)
            .food(new FoodProperties.Builder().nutrition(1).saturationMod(0.1F).alwaysEat()
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 1), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.JUMP, 1200, 0), 1.0F).build()), false));
    public static final RegistryObject<Item> WATER = ITEMS.register("water_bottle_viperr", () -> new DrinkItem(new Item.Properties().stacksTo(16)
            .food(new FoodProperties.Builder().nutrition(1).saturationMod(0.1F).alwaysEat().build()), true));

    // ---- food ----
    public static final RegistryObject<Item> HOTDOG = ITEMS.register("hotdog", () -> new Item(new Item.Properties()
            .food(new FoodProperties.Builder().nutrition(6).saturationMod(0.6F).build())));
    public static final RegistryObject<Item> BURGER = ITEMS.register("burger", () -> new Item(new Item.Properties()
            .food(new FoodProperties.Builder().nutrition(8).saturationMod(0.8F).build())));
    public static final RegistryObject<Item> CHIPS = ITEMS.register("chips", () -> new Item(new Item.Properties()
            .food(new FoodProperties.Builder().nutrition(3).saturationMod(0.3F).fast().build())));
}
