package com.viperr.registry;

import com.viperr.Viperr;
import com.viperr.block.DiscoBlock;
import com.viperr.block.DjConsoleBlock;
import com.viperr.block.ViperrPortalBlock;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, Viperr.MODID);

    public static final RegistryObject<Block> VIPERR_ORE = BLOCKS.register("viperr_ore", () ->
            new DropExperienceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .strength(3.5F, 3.5F)
                    .requiresCorrectToolForDrops()
                    .sound(SoundType.STONE),
                    UniformInt.of(2, 5)));

    public static final RegistryObject<Block> VIPERR_BLOCK = BLOCKS.register("viperr_block", () ->
            new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE)
                    .strength(5.0F, 6.0F)
                    .requiresCorrectToolForDrops()
                    .lightLevel(s -> 5)
                    .sound(SoundType.METAL)));

    public static final RegistryObject<Block> PORTAL = BLOCKS.register("viperr_portal", () ->
            new ViperrPortalBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE)
                    .noCollission()
                    .strength(-1.0F)
                    .noOcclusion()
                    .lightLevel(s -> 11)
                    .sound(SoundType.GLASS)));

    public static final RegistryObject<Block> DISCO_FLOOR = BLOCKS.register("disco_floor", () ->
            new DiscoBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE)
                    .strength(-1.0F, 3600000.0F)
                    .lightLevel(s -> 12)
                    .emissiveRendering((s, g, p) -> true)
                    .sound(SoundType.GLASS)));

    public static final RegistryObject<Block> PARTY_LAMP = BLOCKS.register("party_lamp", () ->
            new DiscoBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE)
                    .strength(-1.0F, 3600000.0F)
                    .lightLevel(s -> 15)
                    .emissiveRendering((s, g, p) -> true)
                    .sound(SoundType.GLASS)));

    public static final RegistryObject<Block> DJ_CONSOLE = BLOCKS.register("dj_console", () ->
            new DjConsoleBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .strength(-1.0F, 3600000.0F)
                    .lightLevel(s -> 8)
                    .sound(SoundType.METAL)));
}
