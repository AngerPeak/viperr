package com.viperr.entity;

import com.viperr.Viperr;
import com.viperr.client.ClientHooks;
import com.viperr.registry.ModItems;
import com.viperr.shop.ShopCatalog;
import com.viperr.world.HallLayout;
import com.viperr.world.HallTeleporter;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * One entity type for everybody in the hall: artists, fans, bums, face control, bartender and kiosk seller.
 */
public class ViperrNpc extends PathfinderMob {
    private static final EntityDataAccessor<Integer> DATA_ROLE = SynchedEntityData.defineId(ViperrNpc.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_VARIANT = SynchedEntityData.defineId(ViperrNpc.class, EntityDataSerializers.INT);
    private static final Map<String, ResourceLocation> TEXTURES = new HashMap<>();
    public static final int FAN_VARIANTS = 6;
    public static final int BUM_VARIANTS = 3;

    private boolean hasHome = false;
    private double homeX, homeY, homeZ;
    private long angryUntil = 0;

    public ViperrNpc(EntityType<? extends ViperrNpc> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    // ------------------------------------------------------------------ data

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ROLE, 0);
        this.entityData.define(DATA_VARIANT, 0);
    }

    public NpcRole getRole() {
        return NpcRole.byId(this.entityData.get(DATA_ROLE));
    }

    public int getVariant() {
        return this.entityData.get(DATA_VARIANT);
    }

    public void setVariant(int v) {
        this.entityData.set(DATA_VARIANT, v);
    }

    public void setHome(double x, double y, double z) {
        hasHome = true;
        homeX = x;
        homeY = y;
        homeZ = z;
    }

    public boolean isFace() {
        return getRole() == NpcRole.FACE_CONTROL;
    }

    public void setRole(NpcRole role) {
        this.entityData.set(DATA_ROLE, role.ordinal());
        switch (role) {
            case KAI_ANGEL -> setCustomName(Component.literal("Kai Angel").withStyle(ChatFormatting.BOLD, ChatFormatting.AQUA));
            case NINE_MICE -> setCustomName(Component.literal("9mice").withStyle(ChatFormatting.BOLD, ChatFormatting.RED));
            case FACE_CONTROL -> {
                setCustomName(Component.translatable("entity.viperr.face_control").withStyle(ChatFormatting.BOLD, ChatFormatting.GOLD));
                getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.38D);
                getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(5.0D);
            }
            case BARTENDER -> setCustomName(Component.translatable("entity.viperr.bartender").withStyle(ChatFormatting.BOLD, ChatFormatting.GREEN));
            case VENDOR -> setCustomName(Component.translatable("entity.viperr.vendor").withStyle(ChatFormatting.BOLD, ChatFormatting.YELLOW));
            default -> {
            }
        }
        setCustomNameVisible(false); // the name only shows when you look at the NPC
    }

    public ResourceLocation getTexture() {
        NpcRole r = getRole();
        String name = switch (r) {
            case KAI_ANGEL -> "kai_angel";
            case NINE_MICE -> "nine_mice";
            case FAN -> "fan_" + Math.floorMod(getVariant(), FAN_VARIANTS);
            case BUM -> "bum_" + Math.floorMod(getVariant(), BUM_VARIANTS);
            case FACE_CONTROL -> "face_control";
            case BARTENDER -> "bartender";
            case VENDOR -> "vendor";
        };
        return TEXTURES.computeIfAbsent(name, n -> new ResourceLocation(Viperr.MODID, "textures/entity/" + n + ".png"));
    }

    /** Client side: how many degrees the body is turned right now (crazy dancing fans spin). */
    public float getSpin(float ageInTicks) {
        if (getRole() != NpcRole.FAN) return 0.0F;
        int id = getId();
        if (id % 3 == 0) return 0.0F;
        float speed = 14.0F + (id % 5) * 6.0F;
        return ageInTicks * speed * (id % 2 == 0 ? 1.0F : -1.0F);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Role", getRole().ordinal());
        tag.putInt("Variant", getVariant());
        if (hasHome) {
            tag.putDouble("HomeX", homeX);
            tag.putDouble("HomeY", homeY);
            tag.putDouble("HomeZ", homeZ);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_ROLE, tag.getInt("Role"));
        this.entityData.set(DATA_VARIANT, tag.getInt("Variant"));
        if (tag.contains("HomeX")) {
            setHome(tag.getDouble("HomeX"), tag.getDouble("HomeY"), tag.getDouble("HomeZ"));
        }
        if (isFace()) {
            getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.38D);
            getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(5.0D);
        }
    }

    // ------------------------------------------------------------------ rules

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount);
        }
        if (source.getEntity() instanceof Player p) {
            if (p.isCreative()) return super.hurt(source, amount); // admins can delete NPCs
            if (isFace() && !level().isClientSide) {
                angryUntil = level().getGameTime() + 600;
                setTarget(p);
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ AI

    private boolean shouldChase(LivingEntity target) {
        if (!(target instanceof Player p)) return false;
        if (p.isCreative() || p.isSpectator()) return false;
        if (!level().dimension().equals(HallLayout.HALL)) return false;
        return p.getZ() > HallLayout.CHECK_Z && !HallTeleporter.hasTicket(p);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.35D, true) {
            @Override
            public boolean canUse() {
                return isFace() && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return isFace() && super.canContinueToUse();
            }
        });
        this.goalSelector.addGoal(2, new StageWalkGoal());
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F) {
            @Override
            public boolean canUse() {
                NpcRole r = getRole();
                return (r == NpcRole.FACE_CONTROL || r == NpcRole.BARTENDER || r == NpcRole.VENDOR) && super.canUse();
            }
        });
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<Player>(this, Player.class, 10, false, false, t -> shouldChase(t)) {
            @Override
            public boolean canUse() {
                return isFace() && super.canUse();
            }
        });
    }

    /** Artists walk around the stage. */
    private class StageWalkGoal extends Goal {
        StageWalkGoal() {
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return getRole().isArtist() && getNavigation().isDone() && getRandom().nextInt(40) == 0;
        }

        @Override
        public boolean canContinueToUse() {
            return !getNavigation().isDone();
        }

        @Override
        public void start() {
            double x = HallLayout.WALK_X1 + getRandom().nextInt(HallLayout.WALK_X2 - HallLayout.WALK_X1 + 1) + 0.5;
            double z = HallLayout.WALK_Z1 + getRandom().nextInt(HallLayout.WALK_Z2 - HallLayout.WALK_Z1 + 1) + 0.5;
            getNavigation().moveTo(x, HallLayout.STAGE_Y, z, 0.9D);
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;

        switch (getRole()) {
            case FAN -> {
                if (onGround() && getRandom().nextInt(12) == 0) {
                    Vec3 m = getDeltaMovement();
                    setDeltaMovement(m.x + (getRandom().nextDouble() - 0.5D) * 0.14D, 0.42D, m.z + (getRandom().nextDouble() - 0.5D) * 0.14D);
                    this.hasImpulse = true;
                }
                pullHome(1.6D, 0.04D);
            }
            case BUM -> {
                if (onGround() && getRandom().nextInt(70) == 0) {
                    Vec3 m = getDeltaMovement();
                    setDeltaMovement(m.x + (getRandom().nextDouble() - 0.5D) * 0.25D, 0.0D, m.z + (getRandom().nextDouble() - 0.5D) * 0.25D);
                    this.hasImpulse = true;
                }
                pullHome(2.5D, 0.03D);
            }
            case KAI_ANGEL, NINE_MICE -> {
                if (tickCount % 6 == 0 && level() instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.NOTE, getX(), getY() + 2.3D, getZ(), 1, 0.4D, 0.2D, 0.4D, 1.0D);
                }
            }
            case FACE_CONTROL -> {
                LivingEntity t = getTarget();
                if (t instanceof ServerPlayer sp && level().getGameTime() > angryUntil && HallTeleporter.hasTicket(sp)) {
                    setTarget(null);
                }
                if (t == null && hasHome && distanceToSqr(homeX, homeY, homeZ) > 4.0D && getNavigation().isDone()) {
                    getNavigation().moveTo(homeX, homeY, homeZ, 1.0D);
                }
            }
            default -> {
            }
        }
    }

    private void pullHome(double radius, double force) {
        if (!hasHome) return;
        double dx = homeX - getX();
        double dz = homeZ - getZ();
        double d2 = dx * dx + dz * dz;
        if (d2 > radius * radius) {
            double d = Math.sqrt(d2);
            setDeltaMovement(getDeltaMovement().add(dx / d * force, 0.0D, dz / d * force));
        }
    }

    // ------------------------------------------------------------------ interaction

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        NpcRole role = getRole();
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        switch (role) {
            case FACE_CONTROL -> {
                if (!level().isClientSide && player instanceof ServerPlayer sp) {
                    sellTicket(sp);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            case BARTENDER, VENDOR -> {
                final int shop = role == NpcRole.BARTENDER ? 0 : 1;
                if (level().isClientSide) {
                    DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openShop(shop));
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            default -> {
                return InteractionResult.PASS;
            }
        }
    }

    private void sellTicket(ServerPlayer player) {
        if (HallTeleporter.hasTicket(player)) {
            player.displayClientMessage(Component.translatable("message.viperr.has_ticket"), true);
            return;
        }
        if (ShopCatalog.pay(player, ShopCatalog.TICKET_PRICE)) {
            ShopCatalog.give(player, new ItemStack(ModItems.TICKET.get()));
            level().playSound(null, blockPosition(), SoundEvents.VILLAGER_YES, SoundSource.NEUTRAL, 1.0F, 1.0F);
            player.displayClientMessage(Component.translatable("message.viperr.ticket_sold"), true);
        } else {
            level().playSound(null, blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.NEUTRAL, 1.0F, 0.8F);
            player.displayClientMessage(Component.translatable("message.viperr.ticket_price", ShopCatalog.TICKET_PRICE), true);
        }
    }
}
