package com.viperr.entity;

public enum NpcRole {
    FAN,
    BUM,
    KAI_ANGEL,
    NINE_MICE,
    FACE_CONTROL,
    BARTENDER,
    VENDOR;

    public static NpcRole byId(int id) {
        NpcRole[] v = values();
        return v[Math.floorMod(id, v.length)];
    }

    public boolean isArtist() {
        return this == KAI_ANGEL || this == NINE_MICE;
    }
}
