package com.viperr.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.viperr.Tracks;
import com.viperr.Viperr;
import com.viperr.world.HallBuilder;
import com.viperr.world.HallLayout;
import com.viperr.world.HallManager;
import com.viperr.world.HallTeleporter;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Admin helpers: /viperr hall, /viperr rebuild, /viperr track N */
@Mod.EventBusSubscriber(modid = Viperr.MODID)
public class ViperrCommand {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("viperr")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("hall").executes(ctx -> {
                    HallTeleporter.enterHall(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("rebuild").executes(ctx -> {
                    ServerLevel hall = ctx.getSource().getServer().getLevel(HallLayout.HALL);
                    if (hall == null) {
                        ctx.getSource().sendFailure(Component.literal("VIPERR HALL dimension not found"));
                        return 0;
                    }
                    HallBuilder.rebuild(hall);
                    ctx.getSource().sendSuccess(() -> Component.literal("VIPERR HALL rebuilt"), true);
                    return 1;
                }))
                .then(Commands.literal("track").then(Commands.argument("n", IntegerArgumentType.integer(1, Tracks.COUNT)).executes(ctx -> {
                    ServerLevel hall = ctx.getSource().getServer().getLevel(HallLayout.HALL);
                    if (hall == null) return 0;
                    int n = IntegerArgumentType.getInteger(ctx, "n") - 1;
                    HallManager.setTrack(hall, n);
                    ctx.getSource().sendSuccess(() -> Component.literal("Track: " + Tracks.NAMES[n]), true);
                    return 1;
                }))));
    }
}
