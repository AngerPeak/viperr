package com.viperr.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/** Glowing block with 8 colours. Used for the dance floor and the party lamps. */
public class DiscoBlock extends Block {
    public static final IntegerProperty COLOR = IntegerProperty.create("color", 0, 7);

    public DiscoBlock(Properties props) {
        super(props);
        this.registerDefaultState(this.stateDefinition.any().setValue(COLOR, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(COLOR);
    }
}
